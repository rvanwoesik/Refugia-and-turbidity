#Make sure all files in supps req have been extracted and an RData file has been created from 1 load data.R


library(audio)
library(sp)
library(foreign)
library(rgdal)
library(maptools)
library(rgeos)
library(doParallel)
library(rasterVis)
library(dismo)
library(plotKML)
library(SDMTools)
library(PBSmapping)
library(lme4)
library(blme)
#library(mailR)
library(raster)






load("C:/Users/Chris/Desktop/supps req/yourSavedData.RData") #load initial data
























####################
####################
####################
####################
#################### SET Mechanistic values
########################################



minTolerance<-18.0         #degrees C of minimum tolerance
dispersalDist<-10         #how far the species can disperse each year (KM)
LongitudinalBuffer<-5     #the initial longitudinal buffer for dispersal uncertainty values(0:10) numeric
ProjTime<-86.0             #years until projection (2100)
AdaptationRange<-1        #how much range will the species be able to tolerate in 2100 (can change to time relationship) - 1 degree gain in range tolerance
PAR.limit<-21.6 #value from Kleypas 1997, 250 microE/m^2/s = 21.6 E/m^2/day
Zmax<-3  #set  depth at which light calculation happens




########################################
####################
####################
####################




change.kd_to_PLD<-function(x,Zmax=3){ #for rasters
  x2<-.6677*x^.6763 #kdPAR~kd490 pierson et al. 2007
  Y2<-exp((-1*x2)*Zmax) #percent light at depth zmax
  return(Y2)
}

PLD<-change.kd_to_PLD(kd)


#median.reef.PLD<-0.4570086#from light attenuation median

# tPARmeanFINAL<-crop(PAR.mean,extent(PLD))*median.reef.PLD #training raster

pPARmeanFINAL<-crop(PAR.mean,extent(PLD))*PLD #prediction raster


















#acropora hyacinthus = set 1 i<-58
#plobata = set<-2;i<-398

# cl <- makeCluster(5) # 
# registerDoParallel(cl)
# registerDoParallel(cl)

#read IUCN 
list1<-c(1,1,2,2,2,2,2,1,2,2,2,2)                       #species to choose from
list2<-c(58,30,65,129,140,180,238,233,395,398,455,470)

#for (vers in 6:12){
  vers<-1    # this is the species choosing number, 10 is p.lobata, 1 is a hyacinthus, supps includes A hyacinthus
  set<-list1[vers]
  i<-list2[vers]
  
  setwd("C:/Users/Chris/Desktop/supps req")
  corals2<-read.dbf(paste("CORALS",set,".dbf",sep=""))
  corals<-corals2[order(corals2$binomial),]
  Species<-paste(corals[i,2])
  
  #convert to CRS
  #setwd(paste("C:/Users/Chris/Desktop/van Woesik/IUCN shapes/Coral shapes/Corals",set,sep=""))
  IUCN_dist2<-readOGR(".",paste("CORALS",set,"_binomial__",Species,sep=''))
  IUCN_dist<-spTransform(IUCN_dist2,CRS(newproj))
  
  sparea<-area(IUCN_dist)
  #find ecregions the species is in
  
 
  IUCNinECO<-ecoregions[!is.na(over(ecoregions,IUCN_dist)[,1]),]

  
  print(paste("IUCN data converted to ecoregions",Species))
  
  
  
  
  

  
  
  
  ########## probability ##################################################  Used in Cacciapaglia and van Woesik 2015
  regions<-ereg1[IUCNinECO,2];nregions<-regions #regions the spp is in  
  one2141<-c(1:141)
  absent<- one2141[!one2141 %in% regions] #find the regions the species is not in
  
  
  adjlist<-data.frame() #list of all adjacent regions to the species (includes regions species is in)
  for (j in nregions){
    AdjRegions<-AdjacencyMat[j,1:10]
    adjlist<-rbind(adjlist,AdjRegions)}
  noNAadjlist<-adjlist[!is.na(adjlist)]
  No_Present_Or_NA_adjlist<-noNAadjlist[!noNAadjlist%in%(nregions)]######################### No_Present_Or_NA_adjlist is list of adjacent regions that do not have the species detected, not unique because we sample through the number of iterations
  
  ########## give each initial absent region a probability of 30% to find species on first try.
  problist<-data.frame()
  for (i in 1:141){
    if (i %in% nregions){ # if it is in a region P(detect)=1
      x<-1}
    else{x<-.3} # if not in region P(detect)= .3 
    problist<-rbind(problist,x)                          
  }
  ##################################### initial values set
  
  
  problist1<-c(do.call("cbind",problist))  ################ change .6 as decrease of adjacent regions
  for (i in No_Present_Or_NA_adjlist){
    problist1[i]<-problist1[i]*.6}  ########### everytime a species is detected adjacent to a region the species is absent from, probablility of detection is decreased by 40% because it is more likely the samplers missed it.
  
  ############### incorporate size into P
  
  Plist<-problist1
  for (i in absent){
    size<-sizes[i]
    ratioArea<-(minsize/size)^4 ##for regions the species is absent in take the log area of the region and divide log min area by it
    Plist[i]<-Plist[i]*ratioArea}
  problist<-Plist
  
  if (any(!regions %in% c(123:137))==T){ ## they are not in atlantic
    problist[c(123:137)]<-1 
    ATLvPAC<-1}#caribbean <- known absent
  
  if (any(regions %in% c(123:137))==T){  ## they are in atlantic
    (problist[c(1:122,139:141)]<-1)
    ATLvPAC<-0} # pacific <- known absent
  
  #ATLvPAC is 1 if it is a pacific species
  probmat<-problist
  #probmat
  
  
  cl <- makeCluster(4) # 
  registerDoParallel(cl)
  
  
  #determine which regions the species is likely to be absent
  
  print("p2")
  variance<-foreach (i = 1:141,.combine=rbind,.verbose=F) %dopar% {  ##########################loop it  for variance and Prob of Geometric
    p<-probmat[i]
    nfails<-SEF[i]
    
    maxSE<-max(SEF) #find the maximum value of sampling effort
    
    #geometric distribution for SE out of maxSE
    pgm<-pgeom(nfails,p)#probablility of finding this spp after x trials 
    mx<-pgeom(maxSE,p)#prob of finding after max attempts
    PGM<-pgm /mx  #difference in probablility of finding after x trials - max attempts
    
    #determine variance
    VAR<-(1-p)/p^2  # get the variance
    EXP<-1/p    #expected value
    c(VAR,EXP,nfails,PGM) #combine variance, expected, sampling effort, probability of finding after SE trials
  }
  print("done var")
  
  n<-1
  se<-(sqrt(variance[,2]))/sqrt(n)
  p<-probmat
  #confidence of 95%
  c95<-se*1.96 # determine the 95% confidence of regions
  s95<-((log(1-.95)/log(1-p))-1) # determine the SE at which we are 95% sure we have found it.
  plotsp<-cbind(variance,c95,s95,p)
  rownames(plotsp)<-scip[,1]
  colnames(plotsp)<-(c("var","exp","nfails","ProbFound","c95","s95","p"))
  oplotsp<-plotsp[order(plotsp[,6]),]
  
  
  low_confidence_regions<-foreach (i = 1:141,.combine=rbind)%dopar%{
    if(plotsp[i,4]<.95){i} ####################################### only take ones greater than 95% (could include the confidence of that confidence?)
  }
  lowregions<-scip[low_confidence_regions,1]#if you need the region names
  
  
  stopCluster(cl)
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  ############# shapes of classified regions ############
  #uncertain
  n.regions<-as.numeric(low_confidence_regions[,1]) 
  n.shpregions<-ereg[n.regions,604]
  lowconf<-ecoregions[c(n.shpregions),]   
  
  #present
  p_regions<-regions
  shpregions<-ereg[regions,604]
  this_spp<-ecoregions[c(shpregions),]   
  this_spp<-gBuffer(this_spp,width=0,byid=T)
  
  #absent
  pres_and_uncert<-c(n.regions,p_regions)
  all<-c(1:141)
  no<-setdiff(all,pres_and_uncert)
  certainGone<-ereg[no,604]
  none<-ecoregions[c(certainGone),]  
  
  
  
  
  #sampling numbers
  if(ATLvPAC==1){absentSampleNumber<-(length(none)-15)}
  if(ATLvPAC==0){absentSampleNumber<-(length(none)-125)}
  absentSampleNumber/(length(this_spp)+absentSampleNumber)->ratio
  asamp<-round(3000*ratio);psamp<-round(3000-asamp)
  
  
  print(paste("probability is determined", length(regions),"present",length(no),"absent,","presence samples=",psamp,"absence samples=",asamp))
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  for (CONF in 1:25){
    
    
    
    
    print('start points')
    ############################## extract points
    if(ATLvPAC==1){Atldepth<-AtldepthP}      #species is found in Pacific or Atlantic
    if(ATLvPAC==0){Atldepth<-AtldepthC}
    
    cl <- makeCluster(4) # 
    registerDoParallel(cl)
    
    
    #absence points
    ecoA<-none
    ecoA<-spTransform(ecoA,CRS(proj4string(Atldepth)),force_ring=TRUE)
    ecoA<-gBuffer(ecoA,width=0,byid=F)
    Absintersection<-gIntersection(ecoA,Atldepth)
    
    cuts<-round(asamp/25)
    cutsamp<-round(seq(1,asamp,length.out=cuts))
    
    
    abspts<-foreach(i=1:(cuts-1),.packages="sp",.combine=rbind) %dopar%{
      abspt<-spsample(Absintersection,cutsamp[i+1]-cutsamp[i], type='random',iter=100)
      coordinates(abspt)}
    
    abspts<-SpatialPoints(abspts)
    abspts.<-SpatialPointsDataFrame(abspts,data=data.frame(1:length(abspts)))
    
    #presence points
    ecoP<-this_spp
    ecoP<-spTransform(ecoP,CRS(proj4string(reefs)),force_ring=TRUE)
    
    print('begin over() points')
    inreefs2<-over(reefs,ecoP)
    short<-reefs[!is.na(inreefs2[,1]),]
   
#     list<-over(reefs,ecoP,returnList=T)
#     list3<-as.numeric(list[[1]][1])
#     for(i in 2:141){
#       v<-as.numeric(list[[i]][1])
#       list3<-c(list3,v)
#     }
#     short<-which(!is.na(list3),arr.ind=TRUE)
#     
#     #short<-(list[!is.na(list)])
#     inreefs<-reefs[as.numeric(names(short))]   ####### REEFS INSIDE ECOREGIONS ################
    inreefs<-as.numeric(rownames(inreefs2))
    blure<-paste("determine presence points");print(blure)
    #   stopCluster(cl)
    #   
    #   cl <- makeCluster(5) # 
    #   registerDoParallel(cl)
    
    cuts<-round(psamp/10)
    cutsamp<-round(seq(1,psamp+200,length.out=cuts))
    scuts<-round(seq(1,length(short),length.out=cuts))
    inreefst1<-foreach(i=2:cuts,.packages=c("sp"),.combine=rbind) %dopar%{
      lrfs<-(short[scuts[i-1]:scuts[i]])
      rpoints<-spsample(lrfs,n=(cutsamp[i]-cutsamp[i-1]),"random",iter=100)
      coordinates(rpoints)
    }
    
    inreefst<-SpatialPoints(inreefst1)
    Prespoints1<-SpatialPointsDataFrame(inreefst,data=data.frame(1:length(inreefst)))
    proj4string(Prespoints1)<-proj4string(ecoP)
    testpoint<-(over(Prespoints1,as(ecoP, "SpatialPolygons")))
    tp2<-cbind(testpoint,1:length(testpoint))
    shlst<-tp2[complete.cases(tp2),2] # take only complete cases
    snum<-sample(shlst,psamp) #randomly sample the needed number of values
    Prespoints<-Prespoints1[snum,]
    
    stopCluster(cl)
    
    
    print(paste("done sampling points"))
    
    ########################
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    #################  Regression
    #################  regression
    #################  regression
    #################  regression
    
    proj4string(abspts.)<-newproj
    tabs_pts<-abspts.
    tpts<-Prespoints
    
    pts<-spTransform(tpts,CRS=CRS(nextproj))
    abs_pts<-spTransform(tabs_pts,CRS=CRS(nextproj))
    
    
    ############# CONNECTIVITY LAYER - mask outside 5 degrees  #############
    
    
    longs<-(coordinates(pts)[,1]) #lon of pts
    lats<-(coordinates(pts)[,2])
    rlongs<-round(longs)
    rlats<-round(lats)
    urlon<-unique(rlongs)
    urlat<-unique(rlats)
    turlon<-180+urlon
    
    
    today<-data.frame()
    for (i in 1:LongitudinalBuffer) {
      today<-c(today,(unique(c(turlon,turlon+i,turlon-i))))  
    }
    
    todayL<-data.frame()
    for (i in 1:LongitudinalBuffer) {
      todayL<-c(todayL,(unique(c(urlat,urlat+i,urlat-i))))  
    }
    
    
    unturlat<-as.numeric(unique(todayL))
    unturlon<-as.numeric(unique(today))
    xc1<-sub(361,1,unturlon);xc2<-sub(362,2,xc1);xc3<-sub(363,3,xc2);xc4<-sub(364,4,xc3);xc5<-sub(365,5,xc4);xc6<-sub(366,6,xc5);xc7<-sub(367,7,xc6);xc8<-sub(368,8,xc7);xc9<-sub(369,9,xc8);xc10<-sub(370,10,xc9)
    xc<-sub( "^0",360,xc10)
    xc12<-sub( "^-1$" ,359,xc);xc13<-sub( -2 ,358,xc12);xc14<-sub( -3 ,357,xc13);xc15<-sub( -4 ,356,xc14);xc16<-sub( -5 ,355,xc15);xc17<-sub( -6 ,354,xc16);xc18<-sub( -7 ,353,xc17);xc19<-sub( -8 ,352,xc18);xc20<-sub( -9 ,351,xc19);xc21<-sub( -10 ,350,xc20)
    
    xct<-as.numeric(xc21)
    uxct<-unique(xct)
    #min(uxct);max(uxct)
    
    mlat<-matrix(ncol=360,nrow=180)
    mlon<-matrix(ncol=360,nrow=180)
    mlon[,uxct]<-1
    mlat[,]<-1
    mlat[90-unturlat,]<-0
    q<-raster(mlon)
    q2<-raster(mlat)
    extent(q)<-c(xmin=-180,xmax=180,ymin=-90,ymax=90)
    q<-crop(q,extent(-180,180,-37,37))
    proj4string(q)<-"xy"
    proj4string(q)<-nextproj
    extent(q2)<-c(xmin=-180,xmax=180,ymin=-90,ymax=90)
    q2<-crop(q2,extent(-180,180,-37,37))
    proj4string(q2)<-"xy"
    proj4string(q2)<-nextproj
    
    
    q<-mask(q,q2,maskvalue=1)
    # plot(q)
    # plot(q2,add=T)
    # points(pts)
    
    #combine lat and lon masks
    q<-resample(q,SST_min_current)
    
    print(paste("Connectivity layer done"))
    
    ##############################################
    
    
    
    
    
    
    
    
    
    
    ####################### KFOLD for HIGHEST AUC ############################ here is first run of the model
    
    cl <- makeCluster(4) # 4 cores
    registerDoParallel(cl)
    
    
    
    perMutations<-100
    pscoreholder <- foreach(i = 1:perMutations, .packages = c("dismo","raster","stats","blme")) %dopar% {
      kfold(pts, 5) ##subset into 5 groups
    }
    ascoreholder <- foreach(i = 1:perMutations, .packages = c("dismo","raster","stats")) %dopar% {
      kfold(abs_pts, 5) ##subset into 5 groups 
    }
    AUC <- foreach(i = 1:perMutations, .packages = c("dismo","raster","stats","lme4"),.combine='c') %dopar% {
      ##subset into 5 groups
      
      pres_train <- pts[c(pscoreholder[[i]]) != 1, ]
      pres_test <- pts[c(pscoreholder[[i]]) == 1, ]
      
      abs_train <- abs_pts[c(ascoreholder[[i]]) != 1, ]
      abs_test <- abs_pts[c(ascoreholder[[i]]) == 1, ]
      
      #extract training values
      presvals1 <- extract(rasters2, pres_train,method="bilinear") #rasters2 has contemporary data
      absvals1 <- extract(rasters2, abs_train,method="bilinear")  #rasters2 has contemporary data
      presvals<-round(presvals1,1)
      absvals<-round(absvals1,1)
      ##format data
      pb <- c(rep(1, nrow(presvals)), rep(0, nrow(absvals)))
      sdmdata <- data.frame(cbind(pb, rbind(presvals, absvals)))
      
      
      
      ####################### MODEL CODE!!!
      ###################
      ###############
      ##########
      ######
      try(gam1 <- bglmer(pb ~SST_range_current*PAR_range+(1|PLD_mean),data=sdmdata,cov.prior=gamma, family = binomial(link = "logit"))) 
      ### AUC = true positives/false positives
      ######
      #########
      ##############
      ##################
      ########################
      
      
      
      ## set up evaluation data
      testpres <- data.frame( extract(rasters, pres_test) )
      testpres<-testpres[complete.cases(testpres),]
      testbackg <- data.frame( extract(rasters, abs_test) )
      testbackg<-testbackg[complete.cases(testbackg),]
      ##
      
      ### evaluate and set a threshold
      
      gam1e <- evaluate(testpres, testbackg, gam1,allow.new.levels=T)
      gam1e@auc
    }
    
    maxAUC<-which.max(AUC)
    
    pres_train <- pts[c(pscoreholder[[maxAUC]]) != 1, ]
    pres_test <- pts[c(pscoreholder[[maxAUC]]) == 1, ]
    
    abs_train <- abs_pts[c(ascoreholder[[maxAUC]]) != 1, ]
    abs_test <- abs_pts[c(ascoreholder[[maxAUC]]) == 1, ]
    
    #extract training values
    presvals <- extract(rasters2, pres_train,method="bilinear") 
    absvals <- extract(rasters2, abs_train,method="bilinear")
    
    ##format data
    pb <- c(rep(1, nrow(presvals)), rep(0, nrow(absvals)))
    sdmdata <- data.frame(cbind(pb, rbind(presvals, absvals)))
    sdmdata[,4]<-round((sdmdata[,4])*2,-1)/2   ####  sdmdata[,4]<-round(sdmdata[,4],1)  sdmdata[,4]<-round((sdmdata[,4]*2),0)/2  
    
    
    print(paste("Kfold finished"))
    
    
    
    stopCluster(cl)
    
    
    
    ####################### RUN initail GAM with  highest AUC   #######
    #################
    ############
    #######
    ####
    
    gam1 <- bglmer(pb ~SST_range_current*PAR_range+(1|PLD_mean),data=sdmdata, family = binomial(link = "logit"),verbose=T,cov.prior=gamma)#,control=glmerControl(optCtrl=list(maxfun=100000) ))
    
    ####
    #######
    ###########
    ###########
    ################
    ####################
    ### AUC = true positives/false positives
    ## set up evaluation data
    testpres <- data.frame( extract(rasters, pres_test) )
    testpres<-testpres[complete.cases(testpres),]
    testbackg <- data.frame( extract(rasters, abs_test) )
    testbackg<-testbackg[complete.cases(testbackg),]
  
    testinga<-rbind(testpres,testbackg)
    ### evaluate and set a threshold
    testing1<-raster(ncol=1,nrow=sum(nrow(testpres),nrow(testbackg)));values(testing1)<-testinga[,1]
    testing2<-raster(ncol=1,nrow=sum(nrow(testpres),nrow(testbackg)));values(testing2)<-testinga[,2]
    testing3<-raster(ncol=1,nrow=sum(nrow(testpres),nrow(testbackg)));values(testing3)<-testinga[,3]
    testing<-stack(testing1,testing2,testing3)
    names(testing)<-names(testinga)
    
    tstd <- predict(testing,gam1,type="response",na.action=na.omit,re.form=NULL,allow.new.levels=T)

    evald<-evaluate(values(tstd)[1:nrow(testpres)],values(tstd)[nrow(testpres):length(values(tstd))])
    
    
    tr<-threshold(evald, 'spec_sens')
    
    gam1e <- evaluate(testpres, testbackg, gam1,re.form=NULL,allow.new.levels=T)
    gam1e@auc
    
    print('predict')
    pgam1.a <- predict(rasters2,gam1,type="response",na.action=na.omit,re.form=NULL,allow.new.levels=T)
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    # 
    # 
    # ################### FUTURE MODEL RUN #######################
    pgam2.a <- predict(Future, gam1,type="response",na.action=na.omit,re.form=NULL,allow.new.levels=T)
    # pgam2B1 <- predict(FutureB1, gam1,type="response",na.action=na.omit,re.form=NULL,allow.new.levels=T)
    # pgam2A1B <- predict(FutureA1B, gam1,type="response",na.action=na.omit,re.form=NULL,allow.new.levels=T)
    # 
    # 
    # #################### ADAPTATION MODEL RUN ###################
    # FTA2<-TempRange2100x-AdaptationRange
    # FTAB1<-TempRangeB1x-AdaptationRange
    # FTAA1B<-TempRangeA1Bx-AdaptationRange
    # 
    # adapRasA2<-stack(PAR_rangex,FTA2,pPARmeanFINAL)
    # adapRasB1<-stack(PAR_rangex,FTAB1,pPARmeanFINAL)
    # adapRasA1B<-stack(PAR_rangex,FTAA1B,pPARmeanFINAL)
    # 
    # 
    # 
    # names(adapRasA2)<-c('PAR_range','SST_range_current','PLD_mean')
    # adapRasA2<-crop(adapRasA2,extent(-180,180,-37,37))
    # pgam3 <- predict(adapRasA2, gam1,type="response",na.action=na.omit,re.form=NULL,allow.new.levels=T)
    # 
    # names(adapRasB1)<-c('PAR_range','SST_range_current','PLD_mean')
    # adapRasB1<-crop(adapRasB1,extent(-180,180,-37,37))
    # pgam3B1 <- predict(adapRasB1, gam1,type="response",na.action=na.omit,re.form=NULL,allow.new.levels=T)
    # 
    # names(adapRasA1B)<-c('PAR_range','SST_range_current','PLD_mean')
    # adapRasA1B<-crop(adapRasA1B,extent(-180,180,-37,37))
    # pgam3A1B <- predict(adapRasA1B, gam1,type="response",na.action=na.omit,re.form=NULL,allow.new.levels=T)
    # 
    # print(paste("Contemporary, Future, and adaptation models run"))
    # 
    # 
    # 
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
   
    
    pgam1<-pgam1.a
    pgam2<-pgam2.a
    
    
    
    ######################
    ##################
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    ############### First Masking ################
    
    ## mask out reef, temp<18, and longitude
    
    print('masking 1')
    maskreef<-mask(pgam1,mask_deep_bathy,maskvalue=NA) #mask less than 20 meters
    mask_temp_reef<-mask(maskreef,SST_min_current>minTolerance,maskvalue=0) #mask less than the minimum tolerance degrees C
    mask_temp_reef_lon<-mask(mask_temp_reef,q,maskvalue=NA) #mask outside distribution
    mask_temp_reef_lon<-mask(mask_temp_reef_lon,riversBuffer,inverse=T) #mask rivers
    mask_temp_reef_lon<-mask(mask_temp_reef_lon,pPARmeanFINAL<PAR.limit,maskvalue=1)#mask too low light
    mask_temp_reef_lon_ATL<-mask(mask_temp_reef_lon,ATL,inverse=T) #mask the Atlantic
    
    
    
    
    
    
    
    
    ##################### DISPERSAL BETWEEN TIME PERIODS ####################
    print('start dispersal')
    initdistr<-(mask_temp_reef_lon_ATL > tr)
    initdistr[initdistr==0] <- NA
    dispdistKM<-dispersalDist*ProjTime
    
    
    lx<-5330-dispersalDist*333 ## random points to be taken from the distribution, should cover all # using this formula, 1km samples 5000 pts, and 10 samples 2000, ranging linearly between
    prand<-randomPoints(initdistr,lx)  #take random background points to cover extent #transform CRS for projection
    
    sprand<-SpatialPoints(prand)
    proj4string(sprand) <- CRS(nextproj)
    lox<-spTransform(sprand,CRS(newproj))
    
    IDK<-gBuffer(lox,width=(dispdistKM*1000),byid=F) ## buffer by the distance of dispersal
    
    #polygon to raster
    sdxprand<-SpatialPolygonsDataFrame(IDK,data=data.frame(1),match.ID=F)
    idk<-vect2rast(sdxprand,cell.size=70000)
    rasBuf<-(raster(idk))
    reprojRB2<-projectRaster(rasBuf,crs=CRS(nextproj))
    reprojRB3<-reprojRB2>0
    reprojRB4<-crop(reprojRB3,extent(pgam1))
    reprojRB<-resample(reprojRB4,pgam1)
    
    print(paste("DISPERSAL BETWEEN TIME PERIODS done"))
    
    
    
    
    
    
    
    
    
    
    
    
    
    ################# MODEL ACCURACY #####################
    presconfusion<-data.frame(extract(pgam1,pts));names(presconfusion)<-'x'
    absconfusion<-data.frame(extract(pgam1,abs_pts));names(absconfusion)<-"x"
    conmat<-rbind(presconfusion,absconfusion)
    pi.hat <- exp(conmat)/(1 + exp(conmat))
    pball <- c(rep(1, nrow(pts)), rep(0, nrow(abs_pts)))
    flop<-cbind(pball,pi.hat)
    flopx<-flop[complete.cases(flop),]
    Lost<-confusion.matrix(flopx$pball,flopx$x,threshold=.5)
    ModelAccuracy<-(Lost[1,1]+Lost[2,2])/(Lost[1,1]+Lost[1,2]+Lost[2,1]+Lost[2,2])
    OM<-omission(Lost)
    Sens<-sensitivity(Lost)
    Specifi<-specificity(Lost)
    PropC<-prop.correct(Lost)
    h1<-paste(ModelAccuracy,"Model Accuracy")
    h2<-paste(OM,"omission")
    h3<-paste(Sens,"sensitivity")
    h4<-paste(Specifi,"specificity")
    h5<-paste(PropC,"prop.correct")
    
    
    
    print(paste("Model accuracy done"))
    
    
    
  
    maskreef2<-mask(pgam2,mask_deep_bathy,maskvalue=NA)
    #### mask out all future places where min is less than 18 degrees
    mask_temp_reef2<-mask(maskreef2,SST_min_future>minTolerance,maskvalue=0) #mask too low of temperatures
    mask_temp_reef_lon2<-mask(mask_temp_reef2,reprojRB>0,maskvalue=NA) #mask distribution
    mask_temp_reef_lon2<-mask(mask_temp_reef_lon2,riversBuffer,inverse=T) #mamsk rivers
    mask_temp_reef_lon2<-mask(mask_temp_reef_lon2,pPARmeanFINAL<PAR.limit,maskvalue=1)#mask too low light
    
    mask_temp_reef_lon_ATL2<- mask(mask_temp_reef_lon2,ATL,inverse=T) #mask atlantic ocean
    
    print(paste("masking 2 done"))
  
    proj4string(mask_temp_reef_lon_ATL)<-CRS("+proj=longlat")
    
    ####### Area Stats # make sure MASS package is not loaded in order to use area for raster
    
    slick<-matrix(ncol=1,nrow=5,data=NA,dimnames=list(c("current","lost",'future','new','change'),c("A2")))
    for (i in 2){
      p<-1
      
      a<-area(mask_temp_reef_lon_ATL)## the area of cells in meters^2? MAKE SURE MASS IS DETACHED
      #deepmask<-mask(a,mask_temp_reef_lon_ATL2)
      #assign(paste0("deepmask",i),mask(a,get(paste("mask_temp_reef_lon_ATL",i,sep=''))>tr))
      
      #current area
      curhab1<-mask(a,mask_temp_reef_lon_ATL>tr)
      curhab<-mask(curhab1,mask_temp_reef_lon_ATL>tr,maskvalue=0)
      curhabval<-(cellStats(curhab,sum)) #-66120
      slick[1,p]<-curhabval
      
      
      #lost
      pizza<-sum((get(paste("mask_temp_reef_lon_ATL",i,sep=''))>tr),(-2*(mask_temp_reef_lon_ATL>tr)),na.rm=F)
      zz2<-mask(a,pizza==(-2),maskvalue=0)
      assign(paste0("losthab",i),mask(zz2,pizza==(-2),maskvalue=NA)) 
      assign(paste0("losthabval",i),cellStats(get(paste("losthab",i,sep='')),sum))
      slick[2,p]<-get(paste("losthabval",i,sep=''))
      
      #future area
      zz4<-mask(a,(get(paste("mask_temp_reef_lon_ATL",i,sep=''))>tr),maskvalue=0)
      assign(paste0("futarea",i),mask(zz4,(get(paste("mask_temp_reef_lon_ATL",i,sep=''))>tr),maskvalue=NA))  
      assign(paste0("futareaval",i),cellStats(get(paste("futarea",i,sep="")),sum))
      slick[3,p]<-get(paste("futareaval",i,sep=''))
      
      
      #new habitat gained
      assign(paste0("gain",i),mask((get(paste("futarea",i,sep=''))),curhab,inverse=T))
      assign(paste0("gainval",i),cellStats(get(paste("gain",i,sep='')),sum))
      slick[4,p]<-get(paste("gainval",i,sep=''))
      
      
      #percent changed
      assign(paste0("habchange",i),-(1-(get(paste("futareaval",i,sep=''))/curhabval))) # change in habitat
      slick[5,p]<-get(paste("habchange",i,sep=''))
      
      print(i)
    }
    
    
    slick<-rbind(slick,c(gam1e@auc));rownames(slick)[6]<-"auc"
    slick<-rbind(slick,c(Species));rownames(slick)[7]<-"species"
    slick<-rbind(slick,c(paste(Sys.Date())));rownames(slick)[8]<-"time"
    slick<-rbind(slick,c(paste(print(VarCorr(gam1),comp=c("Variance")))));rownames(slick)[9]<-"Variance"
    slick<-rbind(slick,c(paste(sqrt(diag(VarCorr(gam1)$PLD_mean)))));rownames(slick)[10]<-"Std.Dev."
    
    print('slick')
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    if(CONF==1){
      
      valeus<-(zonal(losthab2>0, init(losthab2, v='row'), fun='sum'))
      pagain<-gain2>0
      gains<-(zonal(pagain,init(pagain, v='row'), fun='sum'))
      
      lonplot<-40 #what lattitude you want the map to show
      btwnlons<-lonplot-37
      
      kmlost2<-valeus[,2]*9.3^2 #9.3*9.3 per raster cell
      kmlost<-c(rep(0,12*btwnlons),kmlost2,rep(0,12*btwnlons))
      rlos<-length(kmlost) #the length for the derivplot
      zmean<-c(0,0,0)
      for (i in 3:(length(kmlost)-4)){
        p<-mean(kmlost[c(i-3,i-2,i-1,i,i+1,i+2,i+3)])
        zmean<-c(zmean,p)
      }
      finmena<-c(zmean,0,0,0)
      
      
      kmgain2<-gains[,2]*9.3^2
      kmgain<-c(rep(0,12*btwnlons),kmgain2,rep(0,12*btwnlons))
      zmean<-c(0,0,0)
      for (i in 3:(length(kmlost)-4)){
        p<-mean(kmgain[c(i-3,i-2,i-1,i,i+1,i+2,i+3)])
        zmean<-c(zmean,p)
      }
      fingain<-c(zmean,0,0,0)
      
      
      
      
      closeer3<-cbind(finmena,fingain)
      closeer2<-cbind(closeer3,rowSums(closeer3));colnames(closeer2)[3]<-'sum'
      closeer1<-cbind(closeer2,max(closeer2[,3])-closeer2[,2]);colnames(closeer1)[4]<-'g second'
      
      
      
      
      
      
      
      tmask_temp_reef_lon_ATL2<-mask_temp_reef_lon_ATL2
      tmask_temp_reef_lon_ATL<-mask_temp_reef_lon_ATL
      tlosthab2<-losthab2
      
      extent(tmask_temp_reef_lon_ATL2)<-c(0,360,-37,37)
      tmask_temp_reef_lon_ATL2<-rotate(tmask_temp_reef_lon_ATL2)
      extent(tmask_temp_reef_lon_ATL2)<-c(0,360,-37,37)
      
      extent(tmask_temp_reef_lon_ATL)<-c(0,360,-37,37)
      tmask_temp_reef_lon_ATL<-rotate(tmask_temp_reef_lon_ATL)
      extent(tmask_temp_reef_lon_ATL)<-c(0,360,-37,37)
      
      extent(tlosthab2)<-c(0,360,-37,37)
      tlosthab2<-rotate(tlosthab2)
      extent(tlosthab2)<-c(0,360,-37,37)
      
    }
    
    
    
    ####################save load data comps as an workspace
    
    
    print('saving')
    #Save data
    setwd("C:/Users/Chris/Desktop/supps req")
    newdir<-getwd()
    subDir<-Species
    dir.create(file.path(newdir, subDir), showWarnings = FALSE)
    setwd(file.path(newdir, subDir))
    
    if(CONF==1){
      save.image(paste(paste(getwd(),Species,sep="/"),".RData",sep=""))  #saves a workspace file for later use
    }
    
    #save raster
    writeRaster((mask_temp_reef_lon_ATL > tr),paste(Species,CONF,"initial dist.nc"),overwrite=T)
    writeRaster((mask_temp_reef_lon_ATL2 > tr),paste(Species,CONF, "A2","distribution.nc"),overwrite=T)
    
    #save stats
    #write.csv(slick,paste(Species,"model stats",'.csv'))
    if(CONF==1){
     write.table(t(slick),paste("C:/Users/Chris/Desktop/supps req/",Species,"/",Species," table.csv",sep=''),sep=",",row.names = T,col.names=F,append=F) #
}
    if(CONF!=1){
      write.table(t(slick),paste("C:/Users/Chris/Desktop/supps req/",Species,"/",Species," table.csv",sep=''),sep=",",row.names = T,col.names=F,append=T) #
    } 
    # if(CONF==1){
    # zz <- file(paste(Species,"stats auto.txt"),"w")
    # sink(zz)
    # 
    # print(paste("INPUT"))
    # print(paste("#degrees C of minimum tolerance="  ,minTolerance))
    # print(paste("#how far the species can disperse each year KM =",dispersalDist))        
    # print(paste("#the initial longitudinal buffer for dispersal uncertainty (degrees) =",LongitudinalBuffer) )
    # print(paste("years until projected time =",ProjTime)) 
    # print(paste("adaptation coef", AdaptationRange))
    # print(paste("    ADAPTATION VALUES"))
    # print(gam1e)
    # print(summary(gam1))
    # print(Lost)
    # cat(paste(h1,h2,h3,h4,h5, sep='\n')   )
    # sink();close(zz)
    # }
    
    
    
    
    
    ################# FIGURES
    
    if(CONF==1){
      png(paste(Species,"synthesis plot.png"),width=1323,height=418)#1323,418
      
      
      layout( matrix( c(1,1,1,1,2,2),ncol=3),widths=c(2,2,1) )
      par(mar = c(5, 5, 6, 0))
      image(land,col=c("white","burlywood"),xlab="Longitude",ylab="Latitude",cex.main=4,cex.lab=1.8,cex.axis=1.2,ylim=c(-lonplot,lonplot),xlim=c(20,290))
      image((tmask_temp_reef_lon_ATL2 > tr),add=T,col=c("#00000000","limegreen"),legend=F)  ### new habitat 
      image((tmask_temp_reef_lon_ATL > tr),add=T,col=c("#00000000","blue"),legend=F)  ### currently inhabited
      image((losthab2>0),add=T,col=c("red"))
      legend("topright",c("lost habitat","gained habitat","retained habitat"),col=c("red","green","blue"),pch=c(16,16,16),box.col=NA,bg="#00000000",cex=1.4)
      box('plot',lty='solid')
      compassRose(345,-30,cex=.5)
      axis(4,tick=T,labels=F,tck=.02)
      
      
      par(mar=c(5,0,6,5),font.lab=1,font.main=1)
      
      plot(finmena,1:length(finmena),type="l",ylim=rev(range(c(1,rlos))),xlim=c(0,max(closeer1[,3])),ann = FALSE,axes=F)
      polygon(finmena,1:length(finmena),col=rgb(.8,.1,.1,alpha=1))
      polygon(closeer1[,4],1:length(finmena),col=rgb(.0,.8,.2,alpha=.5))
      lines(closeer1[,4],1:length(finmena))
      axis(1,cex.axis=1.2,at=(round(seq(0,max(closeer1[,3]),length.out=8),-3)))
      axis(3,cex.axis=1.2,at=(seq(0,max(closeer1[,3]),length.out=8)),labels=c(rev(paste(round(seq(0,max(closeer1[,3]),length.out=8),-3)))))
      axis(4,at=c(0,length(finmena)*.25,length(finmena)/2,length(finmena)*.75,length(finmena)),labels=c("40","20","0","-20","-40"))
      title(xlab=expression(paste("Habitat lost (km"^"2",")")),cex.lab=1.8)
      title(main=expression(paste(" Habitat gained (km"^"2",")")),cex.main=1.8,xpd=T)
      legend(0,1070,"",pch=5,xpd=T,col=rgb(.8,.1,.1,alpha=.5),bg=rgb(.8,.1,.1,alpha=1),cex=.6)
      legend(0,-140,"",pch=5,xpd=T,col=rgb(.0,.8,.2,alpha=.5),bg=rgb(.0,.8,.2,alpha=.5),cex=.6)
      mtext("Latitude",4,cex=1.3,line=3)
      dev.off()
    }
    
    
    ###### notify me of species being completed
    
    
  
    print(Sys.time())
    
    play(sin(1:20000/17)*2)
    
  }
#}

stopCluster(cl)

