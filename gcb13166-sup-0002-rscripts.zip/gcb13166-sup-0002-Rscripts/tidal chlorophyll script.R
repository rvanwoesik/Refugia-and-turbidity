library(raster)
library(blme)

kd<-raster("C:/Users/Chris/Desktop/supps req/mean kd 1998-2007 9km.nc ")



change.kd_to_PLD<-function(x,Zmax=3){ #for rasters
  x2<-.6677*x^.6763 #kdPAR~kd490 pierson et al. 2007
  Y2<-exp((-1*x2)*Zmax) #percent light at depth zmax
  return(Y2)
}

Irr<-change.kd_to_PLD(kd)

chl<-raster("C:/Users/Chris/Desktop/supps req/SWFMO_CHLO.CR.timeAverage.1998-2007.nc") 


tides<-raster("C:/Users/Chris/Desktop/supps req/global m2 tide.nc")


chl<-crop(chl,extent(Irr))
tides<-resample(rotate(tides),Irr)


all<-stack(Irr,chl,tides)
library(dismo)






############# set pts
num<-15000



pts<-randomPoints(all,num) #ext=c(set extent for points)

vals<-extract(all,pts)
total<-cbind(vals,pts)

total<-total[complete.cases(total),]
final<-cbind(total,round(total[,5]));colnames(final)<-c("Irr","chl",'amplitude','x','y','latcell')
final<-as.data.frame(final)


#raw data
plot(final$chl,final$Irr)
plot(final$amplitude,final$Irr)

plot(final$chl,final$latcell)


#linear model
lin<-lm(final$Irr~(final$chl)+(final$amplitude))
summary(lin)

plot(final$chl,final$Irr);points(final$chl,predict(lin),col='blue',pch=1)
plot(final$amplitude,final$Irr);points(final$amplitude,predict(lin),col='blue',pch=1)




##  GAM
library(mgcv)
fit<-gam(final[,1]~s(final[,2])+s(final[,3]))
summary(fit)
plot(fit)




## GLM
glmfit<-glm(final$Irr~(final$chl)+(final$amplitude))
summary(glmfit)




# Bayesian GL Mixed Effects Model
library(blme)
bfit<-bglmer(final$Irr ~ final$chl + (0 + final$chl|final$latcell) + final$amplitude,cov.prior = gamma,family=gaussian(link = "log"))
## irradiance ~ Chlorophyll + chlorophyll with random intercept and slope for latitude + tidal amplitude
summary(bfit)
plot(bfit)


















lats<-bfit@pp$Zt@Dimnames[[1]]
X<-bfit@u
Y<- bfit@pp$Utr
# bfit@pp$delu
plot(lats,X)
# plot(lats,bfit@pp$Utr)
# plot(lats,bfit@pp$delu)

plot(lats,bfit@pp$Utr*bfit@pp$Utr)

























######### ATLANTIC
set.seed(0)
library(rgdal)
newproj <- "+proj=merc +lon_0=150 +k=1 +x_0=0 +y_0=0 +ellps=WGS84 +towgs84=0,0,0,0,0,0,0 +units=m +no_defs" #utm
nextproj<-"+proj=longlat +datum=WGS84 +ellps=WGS84 +towgs84=0,0,0" #latlong
ATL<-readOGR("C:/Users/Chris/Desktop/supps req","ATL")
ATL<-spTransform(ATL,CRS=CRS(nextproj))

bfit<-bglmer(final$Irr ~ final$chl + (0 + final$chl|final$latcell) + final$amplitude,cov.prior = gamma,family=gaussian(link = "log"))
CHLX<-bfit@u

# r1 <- raster(nrows=108, ncols=21, xmn=0, xmx=10)
# extent(r1)<-c(50,180,-37,37)
for(i in 1:50){
  num<-15000
  #   pts<-randomPoints(mask=all,n=num,ext=r1) #ext=c(set extent for points)
  pts<-spsample(ATL,num,'random')
  # image(all,1);points(pts,pch='.')
  vals<-extract(all,pts)
  total<-cbind(vals,coordinates(pts))
  total<-total[complete.cases(total),]
  final<-cbind(total,round(total[,5]));colnames(final)<-c("Irr","chl",'amplitude','x','y','latcell')
  final<-as.data.frame(final)
  
  bfit<-bglmer(final$Irr ~ final$chl + (0 + final$chl|final$latcell) + final$amplitude,cov.prior = gamma,family=gaussian(link = "log"))
  CHLX<-cbind(CHLX,bfit@u)
  Y<-cbind(Y,bfit@pp$Utr)
  print(i)
}

bfit<-bglmer(final$Irr ~ final$chl + (0 + final$amplitude|final$latcell) + final$amplitude,cov.prior = gamma,family=gaussian(link = "log"))
Y<- bfit@pp$Utr
AMPX<-bfit@u

for(i in 1:50){
  num<-15000
  #pts<-randomPoints(all,num,ext=r1) #ext=c(set extent for points)
  pts<-spsample(ATL,num,'random')
  # image(all,1);points(pts,pch='.')
  vals<-extract(all,pts)
  total<-cbind(vals,coordinates(pts))
  total<-total[complete.cases(total),]
  final<-cbind(total,round(total[,5]));colnames(final)<-c("Irr","chl",'amplitude','x','y','latcell')
  final<-as.data.frame(final)
  
  bfit<-bglmer(final$Irr ~ final$chl + (0 + final$amplitude|final$latcell) + final$amplitude,cov.prior = gamma,family=gaussian(link = "log"))
  AMPX<-cbind(AMPX,bfit@u)
  Y<-cbind(Y,bfit@pp$Utr)
  print(i)
}




######### plot together
CHLV<-rowMeans(CHLX)
AMPV<-rowMeans(AMPX)
lats<-bfit@pp$Zt@Dimnames[[1]]
mav <- function(x,n=5){filter(x,rep(1/n,n), sides=2)}

library(coda)
HPDinterval(mcmc(CHLX[,1]), 0.95)

L<-mav(CHLV,n=6)
Z<-mav(AMPV,n=6)

bounds1<-HPDinterval(mcmc(t(CHLX)), 0.95)
bounds2<-HPDinterval(mcmc(t(AMPX)), 0.95)
# setwd()


tiff(file = "CHL_AMP atlantic.png", width = 5, height = 6.4,unit='in',res=300)


plot(CHLV,lats,pch=1,xlim=c(min(c(CHLX,AMPX)),max(c(CHLX,AMPX))),ylab='Latitude',col='green',cex=.8,xlab='Random effect slope')
points(AMPV,lats,pch=16,col='deepskyblue')

#points(bounds1[,1],lats,type='l')
#points(bounds1[,2],lats,type='l')

polygon(c( rev(bounds1[,2]),bounds1[,1]),c(rev(lats),lats) ,col ='green')
polygon(c( rev(bounds2[,2]),bounds2[,1]),c(rev(lats),lats) ,col ="blue")
legend('topleft',c('Chlorophyll','Tidal Amplitude'),col=c('green','blue'),pch=16,lwd=3,cex=1)


dev.off()
















################## central pacific (upwelling)


set.seed(0)
library(rgdal)
newproj <- "+proj=merc +lon_0=150 +k=1 +x_0=0 +y_0=0 +ellps=WGS84 +towgs84=0,0,0,0,0,0,0 +units=m +no_defs" #utm
nextproj<-"+proj=longlat +datum=WGS84 +ellps=WGS84 +towgs84=0,0,0" #latlong
#ATL<-readOGR("C:/Users/Chris/Desktop/van Woesik/SHAPES/Ocean","ATL")
#ATL<-spTransform(ATL,CRS=CRS(nextproj))
pac<-mask(all,ATL,inverse=T)


bfit<-bglmer(final$Irr ~ final$chl + (0 + final$chl|final$latcell) + final$amplitude,cov.prior = gamma,family=gaussian(link = "log"))
CHLX<-bfit@u

r1 <- raster(nrows=108, ncols=21, xmn=0, xmx=10)
extent(r1)<-c(-180,-50,-37,37)
for(i in 1:50){
  num<-15000
  pts<-randomPoints(mask=pac,n=num,ext=r1) #ext=c(set extent for points)
  #pts<-spsample(ATL,num,'random')
  image(pac,1);points(pts,pch='.')
  vals<-extract(all,pts)
  total<-cbind(vals,coordinates(pts))
  total<-total[complete.cases(total),]
  final<-cbind(total,round(total[,5]));colnames(final)<-c("Irr","chl",'amplitude','x','y','latcell')
  final<-as.data.frame(final)
  
  bfit<-bglmer(final$Irr ~ final$chl + (0 + final$chl|final$latcell) + final$amplitude,cov.prior = gamma,family=gaussian(link = "log"))
  CHLX<-cbind(CHLX,bfit@u)
  Y<-cbind(Y,bfit@pp$Utr)
  print(i)
}

bfit<-bglmer(final$Irr ~ final$chl + (0 + final$amplitude|final$latcell) + final$amplitude,cov.prior = gamma,family=gaussian(link = "log"))
Y<- bfit@pp$Utr
AMPX<-bfit@u

for(i in 1:50){
  num<-15000
  pts<-randomPoints(mask=pac,n=num,ext=r1)
  #   pts<-spsample(ATL,num,'random')
  # image(all,1);points(pts,pch='.')
  vals<-extract(all,pts)
  total<-cbind(vals,coordinates(pts))
  total<-total[complete.cases(total),]
  final<-cbind(total,round(total[,5]));colnames(final)<-c("Irr","chl",'amplitude','x','y','latcell')
  final<-as.data.frame(final)
  
  bfit<-bglmer(final$Irr ~ final$chl + (0 + final$amplitude|final$latcell) + final$amplitude,cov.prior = gamma,family=gaussian(link = "log"))
  AMPX<-cbind(AMPX,bfit@u)
  Y<-cbind(Y,bfit@pp$Utr)
  print(i)
}




######### plot together
CHLV<-rowMeans(CHLX)
AMPV<-rowMeans(AMPX)
lats<-bfit@pp$Zt@Dimnames[[1]]
mav <- function(x,n=5){filter(x,rep(1/n,n), sides=2)}

library(coda)
HPDinterval(mcmc(CHLX[,1]), 0.95)

L<-mav(CHLV,n=6)
Z<-mav(AMPV,n=6)

bounds1<-HPDinterval(mcmc(t(CHLX)), 0.95)
bounds2<-HPDinterval(mcmc(t(AMPX)), 0.95)
# setwd()


tiff(file = "CHL_AMP central pac (upwelling).png", width = 5, height = 6.4,unit='in',res=300)


plot(CHLV,lats,pch=1,xlim=c(min(c(CHLX,AMPX)),max(c(CHLX,AMPX))),ylab='Latitude',col='green',cex=.8,xlab='Random effect slope')
points(AMPV,lats,pch=16,col='deepskyblue')

#points(bounds1[,1],lats,type='l')
#points(bounds1[,2],lats,type='l')

polygon(c( rev(bounds1[,2]),bounds1[,1]),c(rev(lats),lats) ,col ='green')
polygon(c( rev(bounds2[,2]),bounds2[,1]),c(rev(lats),lats) ,col ="blue")
legend('topleft',c('Chlorophyll','Tidal Amplitude'),col=c('green','blue'),pch=16,lwd=3,cex=1)


dev.off()





























############## just eastern pac to indian (no upwelling)

set.seed(0)
bfit<-bglmer(final$Irr ~ final$chl + (0 + final$chl|final$latcell) + final$amplitude,cov.prior = gamma,family=gaussian(link = "log"))
Y<- bfit@pp$Utr
CHLX<-bfit@u

r1 <- raster(nrows=108, ncols=21, xmn=0, xmx=10)
extent(r1)<-c(50,180,-37,37)
for(i in 1:50){
  num<-12000
  pts<-randomPoints(mask=all,n=num,ext=r1) #ext=c(set extent for points)
  #pts<-spsample(ATL,num,'random')
  # image(all,1);points(pts,pch='.')
  vals<-extract(all,pts)
  total<-cbind(vals,coordinates(pts))
  total<-total[complete.cases(total),]
  final<-cbind(total,round(total[,5]));colnames(final)<-c("Irr","chl",'amplitude','x','y','latcell')
  final<-as.data.frame(final)
  
  bfit<-bglmer(final$Irr ~ final$chl + (0 + final$chl|final$latcell) + final$amplitude,cov.prior = gamma,family=gaussian(link = "log"))
  CHLX<-cbind(CHLX,bfit@u)
  Y<-cbind(Y,bfit@pp$Utr)
  print(i)
}

bfit<-bglmer(final$Irr ~ final$chl + (0 + final$amplitude|final$latcell) + final$amplitude,cov.prior = gamma,family=gaussian(link = "log"))
Y<- bfit@pp$Utr
AMPX<-bfit@u

for(i in 1:50){
  num<-12000
  pts<-randomPoints(all,num,ext=r1) #ext=c(set extent for points)
  #pts<-spsample(ATL,num,'random')
  # image(all,1);points(pts,pch='.')
  vals<-extract(all,pts)
  total<-cbind(vals,coordinates(pts))
  total<-total[complete.cases(total),]
  final<-cbind(total,round(total[,5]));colnames(final)<-c("Irr","chl",'amplitude','x','y','latcell')
  final<-as.data.frame(final)
  
  bfit<-bglmer(final$Irr ~ final$chl + (0 + final$amplitude|final$latcell) + final$amplitude,cov.prior = gamma,family=gaussian(link = "log"))
  AMPX<-cbind(AMPX,bfit@u)
  Y<-cbind(Y,bfit@pp$Utr)
  print(i)
}




######### plot together
CHLV<-rowMeans(CHLX)
AMPV<-rowMeans(AMPX)
lats<-bfit@pp$Zt@Dimnames[[1]]
mav <- function(x,n=5){filter(x,rep(1/n,n), sides=2)}

library(coda)
HPDinterval(mcmc(CHLX[,1]), 0.95)

L<-mav(CHLV,n=6)
Z<-mav(AMPV,n=6)

bounds1<-HPDinterval(mcmc(t(CHLX)), 0.95)
bounds2<-HPDinterval(mcmc(t(AMPX)), 0.95)
# setwd()


tiff(file = "CHL_AMP eastern pac.png", width = 5, height = 6.4,unit='in',res=300)


plot(CHLV,lats,pch=1,xlim=c(min(c(CHLX,AMPX)),max(c(CHLX,AMPX))),ylab='Latitude',col='green',cex=.8,xlab='Random effect slope')
points(AMPV,lats,pch=16,col='deepskyblue')

#points(bounds1[,1],lats,type='l')
#points(bounds1[,2],lats,type='l')

polygon(c( rev(bounds1[,2]),bounds1[,1]),c(rev(lats),lats) ,col ='green')
polygon(c( rev(bounds2[,2]),bounds2[,1]),c(rev(lats),lats) ,col ="blue")
legend('topleft',c('Chlorophyll','Tidal Amplitude'),col=c('green','blue'),pch=16,lwd=3,cex=1)


dev.off()





















##################### EVERYWHERE

set.seed(0)
bfit<-bglmer(final$Irr ~ final$chl + (0 + final$chl|final$latcell) + final$amplitude,cov.prior = gamma,family=gaussian(link = "log"))
Y<- bfit@pp$Utr
CHLX<-bfit@u

for(i in 1:50){
  num<-15000
  pts<-randomPoints(all,num) #ext=c(set extent for points)
  #pts<-spsample(ATL,num,'random')
  # image(all,1);points(pts,pch='.')
  vals<-extract(all,pts)
  total<-cbind(vals,coordinates(pts))
  total<-total[complete.cases(total),]
  final<-cbind(total,round(total[,5]));colnames(final)<-c("Irr","chl",'amplitude','x','y','latcell')
  final<-as.data.frame(final)
  
  bfit<-bglmer(final$Irr ~ final$chl + (0 + final$chl|final$latcell) + final$amplitude,cov.prior = gamma,family=gaussian(link = "log"))
  CHLX<-cbind(CHLX,bfit@u)
  Y<-cbind(Y,bfit@pp$Utr)
  print(i)
}

bfit<-bglmer(final$Irr ~ final$chl + (0 + final$amplitude|final$latcell) + final$amplitude,cov.prior = gamma,family=gaussian(link = "log"))
Y<- bfit@pp$Utr
AMPX<-bfit@u

for(i in 1:50){
  num<-15000
  pts<-randomPoints(all,num) #ext=c(set extent for points)
  #pts<-spsample(ATL,num,'random')
  # image(all,1);points(pts,pch='.')
  vals<-extract(all,pts)
  total<-cbind(vals,coordinates(pts))
  total<-total[complete.cases(total),]
  final<-cbind(total,round(total[,5]));colnames(final)<-c("Irr","chl",'amplitude','x','y','latcell')
  final<-as.data.frame(final)
  
  bfit<-bglmer(final$Irr ~ final$chl + (0 + final$amplitude|final$latcell) + final$amplitude,cov.prior = gamma,family=gaussian(link = "log"))
  AMPX<-cbind(AMPX,bfit@u)
  Y<-cbind(Y,bfit@pp$Utr)
  print(i)
}


######### plot together
CHLV<-rowMeans(CHLX)
AMPV<-rowMeans(AMPX)
lats<-bfit@pp$Zt@Dimnames[[1]]
mav <- function(x,n=5){filter(x,rep(1/n,n), sides=2)}

library(coda)
HPDinterval(mcmc(CHLX[,1]), 0.95)

L<-mav(CHLV,n=6)
Z<-mav(AMPV,n=6)

bounds1<-HPDinterval(mcmc(t(CHLX)), 0.95)
bounds2<-HPDinterval(mcmc(t(AMPX)), 0.95)

# fiveC<-CHLX
# fiveA<-AMPX
# fiftyC<-CHLX
# fiftyA<-AMPX

# setwd()

tiff(file = "CHL_AMP everywhere.png", width = 5, height = 6.4,unit='in',res=300)


plot(CHLV,lats,pch=1,xlim=c(min(c(CHLX,AMPX)),max(c(CHLX,AMPX))),ylab='Latitude',col='green',cex=.8,xlab='Random effect slope')
points(AMPV,lats,pch=16,col='deepskyblue')

#points(bounds1[,1],lats,type='l')
#points(bounds1[,2],lats,type='l')

polygon(c( rev(bounds1[,2]),bounds1[,1]),c(rev(lats),lats) ,col ='green')
polygon(c( rev(bounds2[,2]),bounds2[,1]),c(rev(lats),lats) ,col ="blue")

for (i in 2:ncol(CHLX)){
  #points(CHLX[,i],lats,pch=1,col='green',cex=.8)
  #points(AMPX[,i],lats,pch=16,col='deepskyblue',cex=.8)
}


#points(L,lats,pch=16,col='forestgreen',type='l',lwd=4,lty=2)
#points(Z,lats,pch=16,col='blue',type='l',lwd=4,lty=2)

legend('topleft',c('Chlorophyll','Tidal Amplitude'),col=c('green','blue'),pch=16,lwd=3,cex=1)

dev.off()







































































































######### ATLANTIC
set.seed(0)
library(rgdal)
newproj <- "+proj=merc +lon_0=150 +k=1 +x_0=0 +y_0=0 +ellps=WGS84 +towgs84=0,0,0,0,0,0,0 +units=m +no_defs" #utm
nextproj<-"+proj=longlat +datum=WGS84 +ellps=WGS84 +towgs84=0,0,0" #latlong
#ATL<-readOGR("C:/Users/Chris/Desktop/van Woesik/SHAPES/Ocean","ATL")
#ATL<-spTransform(ATL,CRS=CRS(nextproj))

bfit<-bglmer(final$Irr ~ final$chl + (0 + final$chl|final$latcell) + final$amplitude,cov.prior = gamma,family=gaussian(link = "log"))
CHLX<-bfit@u

# r1 <- raster(nrows=108, ncols=21, xmn=0, xmx=10)
# extent(r1)<-c(50,180,-37,37)
for(i in 1:50){
  num<-15000
  #   pts<-randomPoints(mask=all,n=num,ext=r1) #ext=c(set extent for points)
  pts<-spsample(ATL,num,'random')
  # image(all,1);points(pts,pch='.')
  vals<-extract(all,pts)
  total<-cbind(vals,coordinates(pts))
  total<-total[complete.cases(total),]
  final<-cbind(total,round(total[,5]));colnames(final)<-c("Irr","chl",'amplitude','x','y','latcell')
  final<-as.data.frame(final)
  
  bfit<-bglmer(final$Irr ~ final$chl + (0 + final$chl|final$latcell) + final$amplitude,cov.prior = gamma,family=gaussian(link = "log"))
  CHLX<-cbind(CHLX,bfit@u)
  Y<-cbind(Y,bfit@pp$Utr)
  print(i)
}

bfit<-bglmer(final$Irr ~ final$chl + (0 + final$amplitude|final$latcell) + final$amplitude,cov.prior = gamma,family=gaussian(link = "log"))
Y<- bfit@pp$Utr
AMPX<-bfit@u

for(i in 1:50){
  num<-15000
  #pts<-randomPoints(all,num,ext=r1) #ext=c(set extent for points)
  pts<-spsample(ATL,num,'random')
  # image(all,1);points(pts,pch='.')
  vals<-extract(all,pts)
  total<-cbind(vals,coordinates(pts))
  total<-total[complete.cases(total),]
  final<-cbind(total,round(total[,5]));colnames(final)<-c("Irr","chl",'amplitude','x','y','latcell')
  final<-as.data.frame(final)
  
  bfit<-bglmer(final$Irr ~ final$chl + (0 + final$amplitude|final$latcell) + final$amplitude,cov.prior = gamma,family=gaussian(link = "log"))
  AMPX<-cbind(AMPX,bfit@u)
  Y<-cbind(Y,bfit@pp$Utr)
  print(i)
}




######### plot together
CHLV<-rowMeans(CHLX)
AMPV<-rowMeans(AMPX)
lats<-bfit@pp$Zt@Dimnames[[1]]
mav <- function(x,n=5){filter(x,rep(1/n,n), sides=2)}

library(coda)
HPDinterval(mcmc(CHLX[,1]), 0.95)

L<-mav(CHLV,n=6)
Z<-mav(AMPV,n=6)

bounds1<-HPDinterval(mcmc(t(CHLX)), 0.95)
bounds2<-HPDinterval(mcmc(t(AMPX)), 0.95)
# setwd()


tiff(file = "CHL_AMP atlantic.png", width = 5, height = 6.4,unit='in',res=300)


plot(CHLV,lats,pch=1,xlim=c(min(c(CHLX,AMPX)),max(c(CHLX,AMPX))),ylab='Latitude',col='green',cex=.8,xlab='Random effect slope')
points(AMPV,lats,pch=16,col='deepskyblue')

#points(bounds1[,1],lats,type='l')
#points(bounds1[,2],lats,type='l')

polygon(c( rev(bounds1[,2]),bounds1[,1]),c(rev(lats),lats) ,col ='green')
polygon(c( rev(bounds2[,2]),bounds2[,1]),c(rev(lats),lats) ,col ="blue")
legend('topleft',c('Chlorophyll','Tidal Amplitude'),col=c('green','blue'),pch=16,lwd=3,cex=1)


dev.off()
















































############## just central pac to indian (no upwelling)

set.seed(0)
bfit<-bglmer(final$Irr ~ final$chl + (0 + final$chl|final$latcell) + final$amplitude,cov.prior = gamma,family=gaussian(link = "log"))
Y<- bfit@pp$Utr
CHLX<-bfit@u

r1 <- raster(nrows=108, ncols=21, xmn=0, xmx=10)
extent(r1)<-c(50,180,-37,37)
for(i in 1:50){
  num<-12000
  pts<-randomPoints(mask=all,n=num,ext=r1) #ext=c(set extent for points)
  #pts<-spsample(ATL,num,'random')
  # image(all,1);points(pts,pch='.')
  vals<-extract(all,pts)
  total<-cbind(vals,coordinates(pts))
  total<-total[complete.cases(total),]
  final<-cbind(total,round(total[,5]));colnames(final)<-c("Irr","chl",'amplitude','x','y','latcell')
  final<-as.data.frame(final)
  
  bfit<-bglmer(final$Irr ~ final$chl + (0 + final$chl|final$latcell) + final$amplitude,cov.prior = gamma,family=gaussian(link = "log"))
  CHLX<-cbind(CHLX,bfit@u)
  Y<-cbind(Y,bfit@pp$Utr)
  print(i)
}

bfit<-bglmer(final$Irr ~ final$chl + (0 + final$amplitude|final$latcell) + final$amplitude,cov.prior = gamma,family=gaussian(link = "log"))
Y<- bfit@pp$Utr
AMPX<-bfit@u

for(i in 1:50){
  num<-15000
  pts<-randomPoints(all,num,ext=r1) #ext=c(set extent for points)
  #pts<-spsample(ATL,num,'random')
  # image(all,1);points(pts,pch='.')
  vals<-extract(all,pts)
  total<-cbind(vals,coordinates(pts))
  total<-total[complete.cases(total),]
  final<-cbind(total,round(total[,5]));colnames(final)<-c("Irr","chl",'amplitude','x','y','latcell')
  final<-as.data.frame(final)
  
  bfit<-bglmer(final$Irr ~ final$chl + (0 + final$amplitude|final$latcell) + final$amplitude,cov.prior = gamma,family=gaussian(link = "log"))
  AMPX<-cbind(AMPX,bfit@u)
  Y<-cbind(Y,bfit@pp$Utr)
  print(i)
}




######### plot together
CHLV<-rowMeans(CHLX)
AMPV<-rowMeans(AMPX)
lats<-bfit@pp$Zt@Dimnames[[1]]
mav <- function(x,n=5){filter(x,rep(1/n,n), sides=2)}

library(coda)
HPDinterval(mcmc(CHLX[,1]), 0.95)

L<-mav(CHLV,n=6)
Z<-mav(AMPV,n=6)

bounds1<-HPDinterval(mcmc(t(CHLX)), 0.95)
bounds2<-HPDinterval(mcmc(t(AMPX)), 0.95)
# setwd()


tiff(file = "CHL_AMP central pac.png", width = 5, height = 6.4,unit='in',res=300)


plot(CHLV,lats,pch=1,xlim=c(min(c(CHLX,AMPX)),max(c(CHLX,AMPX))),ylab='Latitude',col='green',cex=.8,xlab='Random effect slope')
points(AMPV,lats,pch=16,col='deepskyblue')

#points(bounds1[,1],lats,type='l')
#points(bounds1[,2],lats,type='l')

polygon(c( rev(bounds1[,2]),bounds1[,1]),c(rev(lats),lats) ,col ='green')
polygon(c( rev(bounds2[,2]),bounds2[,1]),c(rev(lats),lats) ,col ="blue")
legend('topleft',c('Chlorophyll','Tidal Amplitude'),col=c('green','blue'),pch=16,lwd=3,cex=1)


dev.off()





















##################### EVERYWHERE

set.seed(0)
bfit<-bglmer(final$Irr ~ final$chl + (0 + final$chl|final$latcell) + final$amplitude,cov.prior = gamma,family=gaussian(link = "log"))
Y<- bfit@pp$Utr
CHLX<-bfit@u

for(i in 1:50){
  num<-15000
  pts<-randomPoints(all,num) #ext=c(set extent for points)
  #pts<-spsample(ATL,num,'random')
  # image(all,1);points(pts,pch='.')
  vals<-extract(all,pts)
  total<-cbind(vals,coordinates(pts))
  total<-total[complete.cases(total),]
  final<-cbind(total,round(total[,5]));colnames(final)<-c("Irr","chl",'amplitude','x','y','latcell')
  final<-as.data.frame(final)
  
  bfit<-bglmer(final$Irr ~ final$chl + (0 + final$chl|final$latcell) + final$amplitude,cov.prior = gamma,family=gaussian(link = "log"))
  CHLX<-cbind(CHLX,bfit@u)
  Y<-cbind(Y,bfit@pp$Utr)
  print(i)
}

bfit<-bglmer(final$Irr ~ final$chl + (0 + final$amplitude|final$latcell) + final$amplitude,cov.prior = gamma,family=gaussian(link = "log"))
Y<- bfit@pp$Utr
AMPX<-bfit@u

for(i in 1:50){
  num<-15000
  pts<-randomPoints(all,num) #ext=c(set extent for points)
  #pts<-spsample(ATL,num,'random')
  # image(all,1);points(pts,pch='.')
  vals<-extract(all,pts)
  total<-cbind(vals,coordinates(pts))
  total<-total[complete.cases(total),]
  final<-cbind(total,round(total[,5]));colnames(final)<-c("Irr","chl",'amplitude','x','y','latcell')
  final<-as.data.frame(final)
  
  bfit<-bglmer(final$Irr ~ final$chl + (0 + final$amplitude|final$latcell) + final$amplitude,cov.prior = gamma,family=gaussian(link = "log"))
  AMPX<-cbind(AMPX,bfit@u)
  Y<-cbind(Y,bfit@pp$Utr)
  print(i)
}


######### plot together
CHLV<-rowMeans(CHLX)
AMPV<-rowMeans(AMPX)
lats<-bfit@pp$Zt@Dimnames[[1]]
mav <- function(x,n=5){filter(x,rep(1/n,n), sides=2)}

library(coda)
HPDinterval(mcmc(CHLX[,1]), 0.95)

L<-mav(CHLV,n=6)
Z<-mav(AMPV,n=6)

bounds1<-HPDinterval(mcmc(t(CHLX)), 0.95)
bounds2<-HPDinterval(mcmc(t(AMPX)), 0.95)

# fiveC<-CHLX
# fiveA<-AMPX
# fiftyC<-CHLX
# fiftyA<-AMPX

# setwd()

tiff(file = "CHL_AMP everywhere.png", width = 5, height = 6.4,unit='in',res=300)


plot(CHLV,lats,pch=1,xlim=c(min(c(CHLX,AMPX)),max(c(CHLX,AMPX))),ylab='Latitude',col='green',cex=.8,xlab='Random effect slope')
points(AMPV,lats,pch=16,col='deepskyblue')

#points(bounds1[,1],lats,type='l')
#points(bounds1[,2],lats,type='l')

polygon(c( rev(bounds1[,2]),bounds1[,1]),c(rev(lats),lats) ,col ='green')
polygon(c( rev(bounds2[,2]),bounds2[,1]),c(rev(lats),lats) ,col ="blue")

for (i in 2:ncol(CHLX)){
  #points(CHLX[,i],lats,pch=1,col='green',cex=.8)
  #points(AMPX[,i],lats,pch=16,col='deepskyblue',cex=.8)
}


#points(L,lats,pch=16,col='forestgreen',type='l',lwd=4,lty=2)
#points(Z,lats,pch=16,col='blue',type='l',lwd=4,lty=2)

legend('topleft',c('Chlorophyll','Tidal Amplitude'),col=c('green','blue'),pch=16,lwd=3,cex=1)

dev.off()





























































############ PACIFIC / INDIAN
newproj <- "+proj=merc +lon_0=150 +k=1 +x_0=0 +y_0=0 +ellps=WGS84 +towgs84=0,0,0,0,0,0,0 +units=m +no_defs" #utm
nextproj<-"+proj=longlat +datum=WGS84 +ellps=WGS84 +towgs84=0,0,0" #latlong
#ATL<-readOGR("C:/Users/Chris/Desktop/van Woesik/SHAPES/Ocean","ATL")
#ATL<-spTransform(ATL,CRS=CRS(nextproj))
Y<- bfit@pp$Utr
X<-bfit@u
pac<-mask(all,ATL,inverse=T)
for(i in 1:10){
  num<-10000
  pts<-randomPoints(pac,num) #ext=c(set extent for points)
  #pts<-spsample(ATL,num,'random')
  # image(all,1);points(pts,pch='.')
  vals<-extract(pac,pts)
  total<-cbind(vals,coordinates(pts))
  total<-total[complete.cases(total),]
  final<-cbind(total,round(total[,5]));colnames(final)<-c("Irr","chl",'amplitude','x','y','latcell')
  final<-as.data.frame(final)
  
  bfit<-bglmer(final$Irr ~ final$chl + (0 + final$amplitude|final$latcell) + final$amplitude,cov.prior = gamma,family=gaussian(link = "log"))
  X<-cbind(X,bfit@u)
  Y<-cbind(Y,bfit@pp$Utr)
  print(i)
}



tiff(file = "CHL_AMP col.png", width = 5, height = 6.4,unit='in',res=300)

plot(CHLX[,1],lats,pch=1,xlim=c(min(c(CHLX,AMPX)),max(c(CHLX,AMPX))),ylab='Latitude',col='green',cex=.8,xlab='Random effect slope')
points(AMPX[,1],lats,pch=16,col='deepskyblue')


for (i in 2:ncol(CHLX)){
  points(CHLX[,i],lats,pch=1,col='green',cex=.8)
  points(AMPX[,i],lats,pch=16,col='deepskyblue',cex=.8)
}


L<-mav(CHLV,n=6)
Z<-mav(AMPV,n=6)
points(L,lats,pch=16,col='forestgreen',type='l',lwd=4,lty=2)
points(Z,lats,pch=16,col='blue',type='l',lwd=4,lty=2)

legend('topleft',c('Chlorophyll','Tidal Amplitude'),col=c('forestgreen','blue'),lty=2,lwd=3,cex=1)

dev.off()
#############3


tiff(file = "CHL_AMP bw.png", width = 5, height = 6.4,unit='in',res=300)

plot(CHLX[,1],lats,pch=1,xlim=c(min(c(CHLX,AMPX)),max(c(CHLX,AMPX))),ylab='Latitude',col=gray(.60),xlab='Random effect slope',cex=.8)
points(AMPX[,1],lats,pch=16,col=gray(.50))
for (i in 2:ncol(CHLX)){
  points(CHLX[,i],lats,pch=1,col=gray(.60),cex=.8)
  points(AMPX[,i],lats,pch=16,col=gray(.50),cex=.8)
}


L<-mav(CHLV,n=6)
Z<-mav(AMPV,n=6)


points(L,lats,pch=16,col=gray(.30),type='l',lwd=4,lty=2)
points(Z,lats,pch=16,col=gray(.20),type='l',lwd=4,lty=1)

legend('topleft',c('Chlorophyll','Tidal Amplitude'),col=c(gray(.30),gray(.20)),lty=c(2,1),lwd=3,cex=.9)

dev.off()




###################


tiff(file = "CHL_AMP col2.png", width = 5, height = 6.4,unit='in',res=300)

plot(CHLX[,1],lats,pch=1,xlim=c(min(c(CHLX,AMPX)),max(c(CHLX,AMPX))),ylab='Latitude',col='green',cex=.8,xlab='Random effect slope')
points(AMPX[,1],lats,pch=16,col='deepskyblue')
for (i in 2:ncol(CHLX)){
  points(CHLX[,i],lats,pch=1,col='green',cex=.8)
  points(AMPX[,i],lats,pch=16,col='deepskyblue',cex=.8)
}


L<-mav(CHLV,n=6)
Z<-mav(AMPV,n=6)
points(L,lats,pch=16,col='forestgreen',type='l',lwd=4,lty=2)
points(Z,lats,pch=16,col='blue',type='l',lwd=4,lty=2)

legend('topleft',c('Chlorophyll','Tidal Amplitude'),col=c('forestgreen','blue'),lty=2,lwd=3,cex=1)

dev.off()



#######################






lats<-bfit@pp$Zt@Dimnames[[1]]


plot(lats,X[,1],pch='.',ylim=c(min(X),max(X)),ylab='random effect variance')
for (i in 2:ncol(X)){
  points(lats,X[,i],pch='.')
}


V<-rowMeans(X)

Yz<-rowMeans(Y)

plot(lats,V,pch=16,col='blue',ylim=c(min(X),max(X)),ylab='random effect variance')
for (i in 2:ncol(X)){
  points(lats,X[,i],pch='.')
}


library(TTR)
L<-SMA(V,7)
plot(lats,L)
l2<-SMA(V,4)
L[4:7]<-l2[4:7]
L[1:3]<-V[1:3]

plot(lats,L,pch=16,col='blue',ylim=c(min(X),max(X)),ylab='Random effect (latitude on chlorophyll)',type='l',lty=2,lwd=3)
for (i in 2:ncol(X)){
  points(lats,X[,i],pch='.')
}



Yz<-rowMeans(Y)
library(TTR)
L<-SMA(Yz,6)
plot(lats,L)
l2<-SMA(Yz,4)
L[4:7]<-l2[4:7]
L[1:3]<-Yz[1:3]

plot(lats,L,pch=16,col='blue',ylim=c(min(Y),max(Y)),ylab='Random effect (latitude on chlorophyll)',type='l',lwd=3,lty=2)
for (i in 2:ncol(X)){
  points(lats,Y[,i],pch='.')
}


XY<-Y*X

Yz<-rowMeans(XY)
library(TTR)
L<-SMA(Yz,6)
plot(lats,L)
l2<-SMA(Yz,4)
L[4:7]<-l2[4:7]
L[1:3]<-Yz[1:3]

plot(lats,L,pch=16,col='blue',ylim=c(min(XY),max(XY)),ylab='Random effect (latitude on chlorophyll)',type='l',lwd=3,lty=2)
for (i in 2:100){
  points(lats,XY[,i],pch='.')
}

















