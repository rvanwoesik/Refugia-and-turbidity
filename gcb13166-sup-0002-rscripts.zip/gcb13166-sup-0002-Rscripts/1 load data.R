library(sp)
library(foreign)
library(rgdal)
library(maptools)
library(rgeos)
library(doParallel)
library(raster)
library(rasterVis)
library(dismo)
library(plotKML)
library(SDMTools)
library(PBSmapping)
library(ncdf)





newproj <- "+proj=merc +lon_0=150 +k=1 +x_0=0 +y_0=0 +ellps=WGS84 +towgs84=0,0,0,0,0,0,0 +units=m +no_defs" #utm
nextproj<-"+proj=longlat +datum=WGS84 +ellps=WGS84 +towgs84=0,0,0" #latlong

############################ RASTERS and old DATA ####################


##Temperature


##Bio-ORACLE (2002-2009) 70N-70S degrees C (higher res)
SST_range_current<-raster("C:/Users/Chris/Desktop/supps req/current/sstrange.asc")
proj4string(SST_range_current)<-"+proj=longlat"

SST_min_current<-raster("C:/Users/Chris/Desktop/supps req/current/sstmin.asc")
proj4string(SST_min_current)<-"+proj=longlat"
SST_min_current<-crop(SST_min_current,extent(-180,180,-37,37))


##Solar Irradiance, SeaWiFS r2010 data between the beginning of 1998 until the end of 2007. http://gdata1.sci.gsfc.nasa.gov/daac-bin/G3/batchDownload.cgi\   #9km resolution range(na.rm=F)

PAR_range<-raster("C:/Users/Chris/Desktop/supps req/PAR range 9km seaWIFS.nc")
proj4string(PAR_range)<- CRS("+proj=longlat")
PAR_rangex<-crop(PAR_range,extent(SST_range_current))



ATL<-readOGR("C:/Users/Chris/Desktop/supps req","ATL")
ATL<-spTransform(ATL,CRS=CRS(nextproj))






##Turbidity

##Flow Rate


##Depth (for now, once background has been limited to reefs(or I can limit the whole globe to area under 20m and do points for reefs(save time), then no need) reef area can be a dbf in ecoregion file...
#   library(marmap)
#   getNOAA.bathy(lon1 = -180, lon2 = 180, lat1 = -70, lat2 = 70, resolution = 5) -> worldbathy
#  wbathy<-as.raster(worldbathy)#to raster
#  wbathy
#  writeRaster(wbathy,"wbathyGAM.nc")
wbathy1<-raster("C:/Users/Chris/Desktop/supps req/high 5min resolution global.nc")
wbathy<-resample(wbathy1,SST_range_current)

##for masking output
mask_deep_bathy<-raster("C:/Users/Chris/Desktop/supps req/global 5 min bathy under 30 buffer.nc")
#wbathy$values>=-20 #get rid of deep water
# # mask_deep_bathy<-resample(mask_deep_bathy,SST_range_current)
# extent(mask_deep_bathy)<-c(-180,180,-70,70)
# #mask_deep_bathy<-rotate(mask_deep_bathy)
# mask_deep_bathy<-crop(mask_deep_bathy,extent(-180,180,-37,37))

##to plot land
land<-wbathy>=0 #get land


#land<-resample(land_bathy,SST_range_current)


#library(maptools)
#data(wrld_simpl)
#plot(wrld_simpl, xlim=c(-180,180), ylim=c(-40,40), axes=TRUE, col='light yellow')
## Life History Traits

#################### River masks
Amazon<-readOGR("C:/Users/Chris/Desktop/supps req","Amazon")            
Congo <-readOGR("C:/Users/Chris/Desktop/supps req","Congo")
Ganges<-readOGR("C:/Users/Chris/Desktop/supps req","Ganges")
Indus<-readOGR("C:/Users/Chris/Desktop/supps req","Indus")
Mekong<-readOGR("C:/Users/Chris/Desktop/supps req","Mekong")
Mississippi<-readOGR("C:/Users/Chris/Desktop/supps req","Mississippi")
Niger <-readOGR("C:/Users/Chris/Desktop/supps req","Niger")
Nile<-readOGR("C:/Users/Chris/Desktop/supps req","Nile")
Orinoco<-readOGR("C:/Users/Chris/Desktop/supps req","Orinoco")
Parana<-readOGR("C:/Users/Chris/Desktop/supps req","Parana")
Yangtze<-readOGR("C:/Users/Chris/Desktop/supps req","Yangtze")
Yellow <-readOGR("C:/Users/Chris/Desktop/supps req","Yellow")
list<-c(Amazon,Congo,Ganges,Indus,Mekong,Mississippi,Niger,Nile,Orinoco,Parana,Yangtze,Yellow)
#combine the rivers
X0<-gUnion(Amazon,Congo);X1<-gUnion(Ganges,Indus);X2<-gUnion(Mekong,Mississippi);X3<-gUnion(Niger,Nile);X4<-gUnion(Orinoco,Parana);X5<-gUnion(Yangtze,Yellow)
Y0<-gUnion(X0,X1);Y1<-gUnion(X2,X3);Y2<-gUnion(X4,X5)
Z1<-gUnion(Y0,Y1)
riversBuffer<-gUnion(Z1,Y2)
##################### read in Future evironmental parameters ##########
##Temperature Range Bio-ORACLE A2 100 years
TempRange2100<-raster("C:/Users/Chris/Desktop/supps req/A2_sstrange_2100_m.asc")
proj4string(TempRange2100)<- CRS("+proj=longlat")
TempRange2100x<-crop(TempRange2100,extent(SST_range_current))

SST_min_future<-raster("C:/Users/Chris/Desktop/supps req/A2_sstmin_2100_m.asc")
proj4string(SST_min_future)<- CRS("+proj=longlat")
SST_min_future<-crop(SST_min_future,extent(-180,180,-37,37))


#read in PAR mean and kd, and nutrients

kd<-raster("C:/Users/Chris/Desktop/supps req/mean kd 1998-2007 9km.nc ")#average light attenuation 490 coefficiten to 1998 to 1007 mean of each layer NA values removed. resolution = .0833333 (9km)
nutrients<-crop(nutrients,extent(-180,180,-37,37))

change.kd_to_PLD<-function(x,Zmax=5){ #for rasters
  x2<-.6677*x^.6763 #kdPAR~kd490 pierson et al. 2007
  Y2<-exp((-1*x2)*Zmax) #percent light at depth zmax
  return(Y2)
}

PLD<-change.kd_to_PLD(kd)
PAR.mean<-raster("C:/Users/Chris/Desktop/supps req/SWFMO_PAR.CR.timeAverage1998-2007.nc")
PAR.limit<-21.6 #value from Kleypas 1997, 250 microE/m^2/s = 21.6 E/m^2/day
median.reef.PLD<-0.4570086#from light attenuation median

tPARmeanFINAL<-crop(PAR.mean,extent(PLD))*median.reef.PLD #training raster
pPARmeanFINAL<-crop(PAR.mean,extent(PLD))*PLD #prediction raster
values(tPARmeanFINAL)<-round(values(tPARmeanFINAL),2)
values(pPARmeanFINAL)<-round(values(pPARmeanFINAL),2)

TempRange2100x<-crop(TempRange2100x,extent(-180,180,-37,37))
PAR_rangex<-crop(PAR_rangex,extent(-180,180,-37,37))

#stack the environmental parameters
Future<-stack(crop(PAR_rangex,extent(-180,180,-37,37)),crop(TempRange2100x,extent(-180,180,-37,37)),pPARmeanFINAL)
proj4string(Future)<- CRS("+proj=longlat")
names(Future)<-c('PAR_range','SST_range_current','PLD_mean')
#Future<-crop(Future,extent(-180,180,-37,37))
################### stack rasters ####

rasters<-stack(crop(PAR_rangex,extent(-180,180,-37,37)),crop(SST_range_current,extent(-180,180,-37,37)),tPARmeanFINAL)
#rasters<-crop(rasters,extent(-180,180,-37,37))
names(rasters)<-c('PAR_range','SST_range_current','PLD_mean')
## more resampling

rasters2<-stack(crop(PAR_rangex,extent(-180,180,-37,37)),crop(SST_range_current,extent(-180,180,-37,37)),pPARmeanFINAL)
names(rasters2)<-c('PAR_range','SST_range_current','PLD_mean')

mask_deep_bathy<-crop(mask_deep_bathy,extent(SST_min_current))
land2<-land
extent(land)<-c(0,360,-70,70)
land<-rotate(land)
extent(land)<-c(0,360,-70,70)



















#load("C:/Users/Chris/Desktop/van Woesik/GAM model/Rasters only loaded.RData") ##load all unchanging needed files

newproj <- "+proj=merc +lon_0=150 +k=1 +x_0=0 +y_0=0 +ellps=WGS84 +towgs84=0,0,0,0,0,0,0 +units=m +no_defs" #utm
nextproj<-"+proj=longlat +datum=WGS84 +ellps=WGS84 +towgs84=0,0,0" #latlong

ecoregions<- readShapeSpatial("C:/Users/Chris/Desktop/supps req/allsppshpC.shp",proj4string = CRS(newproj))#SHAPE !#allsppshpC
ecoregions<-gBuffer(ecoregions,width=0,byid=T)
ecoregions<-ecoregions[c(1:140,142),]

scip<-Coral.species.Indo.PacificC <- read.csv("C:/Users/Chris/Desktop/supps req/Coral species Indo-PacificC.csv",check.names=F)
SEF<-scip[,579] #sampling effort in each region
AdjacencyMat<-read.csv("C:/Users/Chris/Desktop/supps req/AdjacencyMat.csv")

ereg1<-as.data.frame(ecoregions)
ereg<-cbind(ereg1,1:141)
ereg <- ereg[order(ereg$New_No),]

minsize<-log(min(area(ecoregions)))
sizes<-log(area(ecoregions))

AtldepthP<-readOGR("C:/Users/Chris/Desktop/supps req","ATL_depth intersect")

reefs<-readRDS("C:/Users/Chris/Desktop/supps req/reefs.rds")







compassRose<-function(x,y,rot=0,cex=1) { 
  oldcex<-par(cex=cex) 
  mheight<-strheight("M") 
  xylim<-par("usr") 
  plotdim<-par("pin") 
  xmult<-(xylim[2]-xylim[1])/(xylim[4]-xylim[3])*plotdim[2]/plotdim[1] 
  point.angles<-seq(0,7*pi/4,by=pi/4)+pi*rot/180 
  crspans<-rep(c(mheight*3,mheight/2),4) 
  xpoints<-cos(point.angles)*crspans*xmult+x 
  ypoints<-sin(point.angles)*crspans+y 
  polygon(xpoints,ypoints) 
  txtxpoints<-cos(point.angles[c(1,3,5,7)])*1.33*crspans[1]*xmult+x 
  txtypoints<-sin(point.angles[c(1,3,5,7)])*1.33*crspans[1]+y 
  text(txtxpoints,txtypoints,c("E","N","W","S")) 
  par(oldcex) 
} 




############## SAVE WORKSPACE AS... into supps req ###########

