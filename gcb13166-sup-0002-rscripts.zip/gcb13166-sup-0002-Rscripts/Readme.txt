Chris Cacciapaglia
Robert van Woesik
Climate-change refugia: shading reef corals by turbidity
Oct-28-2015

'Turbid model' is used to run the model for turbidity
- file '1 load data' first, check and change working directories to the supplementary location.
	 you have the option to save this as a R workspace which can be recalled faster than re-running the code at the end.
- file '2 Turb model' is set up to run species of interest for example Acropora hyacinthus, and will iterate 25x to gain confidence, a folder will appear with output of
	 each iteration	in your working directory. An image will appear for the first model run to view one iteration, and a table with the stats will be appended throughout the 
	 model runs. 

File 3 'Tidal Chlorophyll' is used to assess the coupling between tidal and chlorophyll driven turbid locations.
- extract and run the R script within.

Species plots are individual plots for each species, one contains the effect of turbidity for contemporary climate, one is the effect of turbidity in 2100, and the other
	is how the species will change in distribution by the year 2100 while incorporating turbidity.

The google Earth images refer to figures 2 and 4 in the manuscript